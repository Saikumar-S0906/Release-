#!/usr/bin/env python3
"""M4 flow quality data — NO tensorflow_datasets. DIV2K + labeled flow."""

from __future__ import annotations

import argparse
import shutil
import sys
import urllib.request
import zipfile
from pathlib import Path

import numpy as np

DIV2K_VALID_HR = "http://data.vision.ee.ethz.ch/cvl/DIV2K/DIV2K_valid_HR.zip"
DIV2K_MIRROR = "https://huggingface.co/datasets/eugenesiow/div2k/resolve/main/DIV2K_valid_HR.zip"
SIZE = 256


def _ensure_path() -> None:
    here = Path(__file__).resolve().parent
    for p in (here, here.parent):
        if str(p) not in sys.path:
            sys.path.insert(0, str(p))


def _count_trips(data: Path) -> int:
    from real_data import flow_triplets

    return len(flow_triplets(data))


def _download(url: str, dest: Path) -> None:
    print(f"downloading {url}", flush=True)

    def _progress(b, bs, t):
        if t and b % 30 == 0:
            print(f"  {min(100, int(100 * b * bs / t))}%", flush=True)

    urllib.request.urlretrieve(url, dest, reporthook=_progress)


def _warp(img: np.ndarray, flow: np.ndarray) -> np.ndarray:
    h, w = img.shape[:2]
    yy, xx = np.mgrid[0:h, 0:w].astype(np.float32)
    x2 = np.clip(xx + flow[..., 0], 0, w - 1)
    y2 = np.clip(yy + flow[..., 1], 0, h - 1)
    x0 = np.floor(x2).astype(np.int32)
    y0 = np.floor(y2).astype(np.int32)
    x1 = np.minimum(x0 + 1, w - 1)
    y1 = np.minimum(y0 + 1, h - 1)
    wx = (x2 - x0)[..., None]
    wy = (y2 - y0)[..., None]
    Ia = img[y0, x0].astype(np.float32)
    Ib = img[y0, x1].astype(np.float32)
    Ic = img[y1, x0].astype(np.float32)
    Id = img[y1, x1].astype(np.float32)
    out = (Ia * (1 - wx) + Ib * wx) * (1 - wy) + (Ic * (1 - wx) + Id * wx) * wy
    return np.clip(out, 0, 255).astype(np.uint8)


def _make_flow(rng: np.random.Generator) -> np.ndarray:
    sh, sw = 8, 8
    small = rng.normal(0, 4.0, size=(sh, sw, 2)).astype(np.float32)
    yi = np.linspace(0, sh - 1, SIZE).astype(np.int32).clip(0, sh - 1)
    xi = np.linspace(0, sw - 1, SIZE).astype(np.int32).clip(0, sw - 1)
    flow = small[yi][:, xi].copy()
    flow[..., 0] += float(rng.uniform(-6, 6))
    flow[..., 1] += float(rng.uniform(-6, 6))
    return flow


def main() -> None:
    _ensure_path()
    try:
        from PIL import Image
    except ImportError:
        import subprocess

        subprocess.check_call([sys.executable, "-m", "pip", "install", "-q", "pillow"])
        from PIL import Image

    parser = argparse.ArgumentParser()
    parser.add_argument("--data", type=Path, default=Path(__file__).parent / "data")
    parser.add_argument("--min", type=int, default=32)
    parser.add_argument("--n", type=int, default=64)
    args = parser.parse_args()
    args.data.mkdir(parents=True, exist_ok=True)
    if _count_trips(args.data) >= args.min and (args.data / "READY").is_file():
        print(f"already ready: {_count_trips(args.data)}", flush=True)
        return

    tmp = args.data / "_download"
    tmp.mkdir(parents=True, exist_ok=True)
    zpath = tmp / "div2k.zip"
    err = None
    imgs: list[Path] = []
    for url in (DIV2K_VALID_HR, DIV2K_MIRROR):
        try:
            _download(url, zpath)
            out = tmp / "imgs"
            out.mkdir(exist_ok=True)
            with zipfile.ZipFile(zpath) as z:
                for info in z.infolist():
                    if info.is_dir():
                        continue
                    name = Path(info.filename).name
                    if Path(name).suffix.lower() not in {".png", ".jpg", ".jpeg"}:
                        continue
                    dest = out / name
                    with z.open(info) as src, open(dest, "wb") as dst:
                        shutil.copyfileobj(src, dst)
                    imgs.append(dest)
            imgs = sorted(imgs)
            if len(imgs) >= args.min:
                break
        except Exception as e:
            err = e
            print(f"failed {url}: {e}", flush=True)
            imgs = []

    if len(imgs) < args.min:
        raise SystemExit(f"DIV2K failed, need ≥{args.min} images. Last: {err}")

    f0, f1, fl = args.data / "frame0", args.data / "frame1", args.data / "flow_npy"
    for d in (f0, f1, fl):
        d.mkdir(parents=True, exist_ok=True)

    rng = np.random.default_rng(44)
    n = min(args.n, len(imgs))
    for i in range(n):
        stem = f"flow_{i:04d}"
        rgb = np.asarray(Image.open(imgs[i]).convert("RGB").resize((SIZE, SIZE)), dtype=np.uint8)
        flow_px = _make_flow(rng)
        warped = _warp(rgb, flow_px)
        Image.fromarray(rgb).save(f0 / f"{stem}.png")
        Image.fromarray(warped).save(f1 / f"{stem}.png")
        np.save(fl / f"{stem}.npy", (flow_px / float(SIZE)).astype(np.float32))
        if (i + 1) % 10 == 0:
            print(f"  saved {i + 1}/{n}", flush=True)

    shutil.rmtree(tmp, ignore_errors=True)
    n_ok = _count_trips(args.data)
    if n_ok < args.min:
        raise SystemExit(f"need ≥{args.min} triplets, found {n_ok}")
    (args.data / "READY").write_text("auto\n", encoding="utf-8")
    print(f"QUALITY data ready: {n_ok} flow triplets", flush=True)


if __name__ == "__main__":
    main()
