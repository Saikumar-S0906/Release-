#!/usr/bin/env python3
"""Verify flow.tflite: 2× RGB 256 → 1x256x256x2 FLOAT32."""

from __future__ import annotations

import argparse
import hashlib
from pathlib import Path

import numpy as np
import tensorflow as tf

from config import ARTIFACT, MAX_APK_BUNDLE_BYTES, MAX_SMOKE_MAE, SIZE
from dataset import make_sample


def main() -> None:
    parser = argparse.ArgumentParser()
    parser.add_argument("--model", type=Path, default=Path(__file__).parent / "dist" / ARTIFACT)
    parser.add_argument("--max-mae", type=float, default=MAX_SMOKE_MAE)
    args = parser.parse_args()
    if not args.model.is_file():
        raise SystemExit(f"missing model: {args.model}")

    data = args.model.read_bytes()
    sha = hashlib.sha256(data).hexdigest()
    interpreter = tf.lite.Interpreter(model_content=data)
    interpreter.allocate_tensors()
    inputs = interpreter.get_input_details()
    outputs = interpreter.get_output_details()
    if len(inputs) != 2 or len(outputs) < 1:
        raise SystemExit(f"expected 2 in / 1 out, got {len(inputs)}/{len(outputs)}")

    shapes = [[int(x) for x in i["shape"]] for i in inputs]
    out_shape = [int(x) for x in outputs[0]["shape"]]
    print(f"in0={shapes[0]} {inputs[0]['dtype']}")
    print(f"in1={shapes[1]} {inputs[1]['dtype']}")
    print(f"out={out_shape} {outputs[0]['dtype']}")
    print(f"sha256={sha}")
    print(f"bytes={len(data)}")
    print(
        "placement=github_release"
        if len(data) > MAX_APK_BUNDLE_BYTES
        else "placement=apk_assets"
    )

    for i in inputs:
        if i["dtype"] != np.float32:
            raise SystemExit("dtype must be float32")
    if outputs[0]["dtype"] != np.float32:
        raise SystemExit("dtype must be float32")
    if shapes[0] != [1, SIZE, SIZE, 3] or shapes[1] != [1, SIZE, SIZE, 3]:
        raise SystemExit(f"input contract failed: {shapes}")
    if out_shape != [1, SIZE, SIZE, 2]:
        raise SystemExit(f"output contract failed: {out_shape}")

    rng = np.random.default_rng(0)
    errs = []
    for _ in range(60):
        fa, fb, flow = make_sample(rng)
        interpreter.set_tensor(inputs[0]["index"], fa[None, ...])
        interpreter.set_tensor(inputs[1]["index"], fb[None, ...])
        interpreter.invoke()
        pred = interpreter.get_tensor(outputs[0]["index"])[0]
        errs.append(float(np.abs(pred - flow).mean()))
    mae = float(np.mean(errs))
    print(f"flow_mae={mae:.4f}")
    if mae > args.max_mae:
        raise SystemExit(f"flow MAE {mae:.4f} exceeds {args.max_mae}")
    print("OK")


if __name__ == "__main__":
    main()
