# Quality data layout (M4 Flow)

**Do not pin Release- weights trained only on synthetic smoke.**

1. Stage triplets:
   - `frame0/` — frame t
   - `frame1/` — frame t+1 (same stem)
   - `flow_npy/` — `stem.npy` HxWx2 float32 (pixels or /SIZE)
2. Touch empty file `READY`
3. Train: `python train.py --quality --data ./data`

Sources: MPI Sintel + FlyingChairs/Things subset. See `tools/ML_QUALITY_BAR.md`.
