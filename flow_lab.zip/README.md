# PixiJoy flow lab (M4)

Optical flow / stabilize assist → `flow.tflite`.

**Ship rule:** only `--quality` + `data/READY`. Smoke ≠ Release-.  
Law: [`../ML_QUALITY_BAR.md`](../ML_QUALITY_BAR.md)

## Contract

| | Shape | Dtype |
|---|-------|-------|
| In0 frame_t | `1×256×256×3` | FLOAT32 |
| In1 frame_t1 | `1×256×256×3` | FLOAT32 |
| Out0 flow | `1×256×256×2` | FLOAT32 `(dx, dy) / SIZE` |

## Quality

Stage Sintel-style `frame0` / `frame1` / `flow_npy` → `READY` → `python train.py --quality`

## Smoke

```bash
python train.py
python export_tflite.py
python verify_contract.py
```
