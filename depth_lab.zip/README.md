# PixiJoy depth lab (M2 / H5)

Monocular relative depth → `depth.tflite`.

**Ship rule:** only `python train.py --quality` after staging `data/READY`. Smoke ≠ Release-.  
Law: [`../ML_QUALITY_BAR.md`](../ML_QUALITY_BAR.md)

## Contract

| | Shape | Dtype |
|---|-------|-------|
| In0 image | `1×256×256×3` | FLOAT32 |
| Out0 depth | `1×256×256×1` | FLOAT32 0..1 (near→far) |

## Colab GPU (recommended)

1. Open: https://colab.research.google.com/github/Saikumar-S0906/Release-/blob/main/train_depth_colab.ipynb
2. Runtime → Change runtime type → **GPU**
3. Runtime → **Run all**
4. Download `depth.tflite` when the last cell finishes
5. Attach it to https://github.com/Saikumar-S0906/Release-/releases/tag/ml-packs-v1 **only after quality gates**

For product quality: stage NYU/KITTI-style pairs → `data/rgb` + `data/depth` → touch `data/READY`, then change the train cell to `python -u train.py --quality`.

## Smoke (contract only)

```bash
python train.py
python export_tflite.py
python verify_contract.py
```
