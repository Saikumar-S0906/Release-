# Quality data layout (M2 Depth)

**Do not pin Release- weights trained only on synthetic smoke.**

1. Stage pairs:
   - `rgb/` — photos (png/jpg)
   - `depth/` — same stem, single-channel relative depth 0..1 (near→far)
2. Touch empty file `READY`
3. Train: `python train.py --quality --data ./data`

Sources: NYU Depth V2 / KITTI (eigen) + phone stills. See `tools/ML_QUALITY_BAR.md`.
