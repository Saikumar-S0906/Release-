#!/usr/bin/env python3
"""M2 depth quality data — NO tensorflow_datasets (Colab protobuf breaks TFDS).

Uses DIV2K real photos + consistent pseudo-depth labels (detail→near, flat→far).
Enough to train/export the frozen LiteRT contract without manual upload.
"""

from __future__ import annotations

import argparse
import shutil
import sys
import urllib.request
import zipfile
from pathlib import Path

import numpy as np

DIV2K_VALID_HR = "http://data.vision.ee.ethz.ch/cvl/DIV2K/DIV2K_valid_HR.zip"
DIV2K_MIRROR = "https://huggingface.co/datasets/eugenesiow/div2k/resolve/main/DIV2K_valid_HR.zip"
SIZE = 256


def _ensure_path() -> None:
    here = Path(__file__).resolve().parent
    for p in (here, here.parent):
        if str(p) not in sys.path:
            sys.path.insert(0, str(p))


def _count_pairs(data: Path) -> int:
    from real_data import depth_pairs

    return len(depth_pairs(data))


def _download(url: str, dest: Path) -> None:
    print(f"downloading {url}", flush=True)

    def _progress(b, bs, t):
        if t and b % 30 == 0:
            print(f"  {min(100, int(100 * b * bs / t))}%", flush=True)

    urllib.request.urlretrieve(url, dest, reporthook=_progress)


def _pseudo_depth(rgb: np.ndarray) -> np.ndarray:
    """Relative depth cue on real RGB (0 near … 1 far). Deterministic, fast."""
    from PIL import Image as _Image

    g = rgb.astype(np.float32).mean(axis=-1)
    g8 = np.clip(g, 0, 255).astype(np.uint8)
    small = np.asarray(_Image.fromarray(g8).resize((SIZE // 8, SIZE // 8)), dtype=np.float32)
    blur = np.asarray(_Image.fromarray(small.astype(np.uint8)).resize((SIZE, SIZE)), dtype=np.float32)
    detail = np.abs(g - blur)
    dmax = float(detail.max()) + 1e-6
    return (1.0 - (detail / dmax)).astype(np.float32)


def _save_from_div2k(zpath: Path, data: Path, n: int) -> int:
    from PIL import Image

    rgb_dir, d_dir = data / "rgb", data / "depth"
    rgb_dir.mkdir(parents=True, exist_ok=True)
    d_dir.mkdir(parents=True, exist_ok=True)
    count = 0
    with zipfile.ZipFile(zpath) as z:
        names = [
            i
            for i in z.namelist()
            if not i.endswith("/") and Path(i).suffix.lower() in {".png", ".jpg", ".jpeg"}
        ]
        for i, name in enumerate(sorted(names)[:n]):
            stem = f"d2k_{i:04d}"
            with z.open(name) as src:
                img = Image.open(src).convert("RGB").resize((SIZE, SIZE))
            rgb = np.asarray(img, dtype=np.uint8)
            depth = _pseudo_depth(rgb)
            img.save(rgb_dir / f"{stem}.png")
            Image.fromarray((depth * 255).astype(np.uint8), mode="L").save(d_dir / f"{stem}.png")
            count += 1
            if count % 10 == 0:
                print(f"  saved {count}", flush=True)
    return count


def main() -> None:
    _ensure_path()
    # pillow
    try:
        import PIL  # noqa: F401
    except ImportError:
        import subprocess

        subprocess.check_call([sys.executable, "-m", "pip", "install", "-q", "pillow"])

    parser = argparse.ArgumentParser()
    parser.add_argument("--data", type=Path, default=Path(__file__).parent / "data")
    parser.add_argument("--min", type=int, default=32)
    parser.add_argument("--n", type=int, default=64)
    args = parser.parse_args()
    args.data.mkdir(parents=True, exist_ok=True)
    if _count_pairs(args.data) >= args.min and (args.data / "READY").is_file():
        print(f"already ready: {_count_pairs(args.data)} pairs", flush=True)
        return

    tmp = args.data / "_download"
    tmp.mkdir(parents=True, exist_ok=True)
    zpath = tmp / "div2k.zip"
    err = None
    for url in (DIV2K_VALID_HR, DIV2K_MIRROR):
        try:
            _download(url, zpath)
            got = _save_from_div2k(zpath, args.data, max(args.n, args.min))
            print(f"built {got} depth pairs from DIV2K", flush=True)
            if _count_pairs(args.data) >= args.min:
                break
        except Exception as e:
            err = e
            print(f"failed {url}: {e}", flush=True)

    shutil.rmtree(tmp, ignore_errors=True)
    n = _count_pairs(args.data)
    if n < args.min:
        raise SystemExit(f"need ≥{args.min} pairs, found {n}. Last: {err}")
    (args.data / "READY").write_text("auto\n", encoding="utf-8")
    print(f"QUALITY data ready: {n} pairs (real RGB + pseudo-depth labels)", flush=True)


if __name__ == "__main__":
    main()
