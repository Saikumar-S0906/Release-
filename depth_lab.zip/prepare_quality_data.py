#!/usr/bin/env python3
"""Fetch public RGB+depth pairs for M2 (auto — no upload).

Primary: TensorFlow Datasets NYU Depth V2 validation.
Writes data/rgb + data/depth (0..1) + READY.
"""

from __future__ import annotations

import argparse
import shutil
import subprocess
import sys
import urllib.request
import zipfile
from pathlib import Path

import numpy as np

RELEASE_SAMPLE = (
    "https://raw.githubusercontent.com/Saikumar-S0906/Release-/main/depth_rgb_sample.zip"
)
SIZE = 256


def _ensure_path() -> None:
    here = Path(__file__).resolve().parent
    for p in (here, here.parent):
        if str(p) not in sys.path:
            sys.path.insert(0, str(p))


def _count_pairs(data: Path) -> int:
    from real_data import depth_pairs

    return len(depth_pairs(data))


def _save_pair(rgb_dir: Path, d_dir: Path, stem: str, rgb: np.ndarray, depth: np.ndarray) -> None:
    from PIL import Image

    rgb_dir.mkdir(parents=True, exist_ok=True)
    d_dir.mkdir(parents=True, exist_ok=True)
    if rgb.dtype != np.uint8:
        rgb_u8 = (np.clip(rgb, 0, 1) * 255).astype(np.uint8) if float(np.max(rgb)) <= 1.5 else rgb.astype(np.uint8)
    else:
        rgb_u8 = rgb
    Image.fromarray(rgb_u8).resize((SIZE, SIZE)).save(rgb_dir / f"{stem}.png")
    d = depth.astype(np.float32)
    if d.ndim == 3:
        d = d[..., 0]
    finite = np.isfinite(d)
    if int(finite.sum()) < 16:
        return
    lo, hi = float(np.percentile(d[finite], 2)), float(np.percentile(d[finite], 98))
    d01 = np.zeros_like(d, dtype=np.float32) if hi - lo < 1e-6 else np.clip((d - lo) / (hi - lo), 0, 1)
    Image.fromarray((d01 * 255).astype(np.uint8), mode="L").resize((SIZE, SIZE)).save(d_dir / f"{stem}.png")


def fetch_tfds_nyu(data: Path, n: int) -> int:
    subprocess.check_call([sys.executable, "-m", "pip", "install", "-q", "tensorflow-datasets", "pillow"])
    import tensorflow_datasets as tfds

    ds = tfds.load("nyu_depth_v2", split=f"validation[:{n}]", shuffle_files=False)
    rgb_dir, d_dir = data / "rgb", data / "depth"
    count = 0
    for i, ex in enumerate(tfds.as_numpy(ds)):
        _save_pair(rgb_dir, d_dir, f"nyu_{i:04d}", ex["image"], ex["depth"])
        count += 1
        if count % 10 == 0:
            print(f"  saved {count}", flush=True)
    return count


def fetch_release_zip(data: Path) -> int:
    tmp = data / "_download"
    tmp.mkdir(parents=True, exist_ok=True)
    zpath = tmp / "sample.zip"
    urllib.request.urlretrieve(RELEASE_SAMPLE, zpath)
    with zipfile.ZipFile(zpath) as z:
        z.extractall(data)
    shutil.rmtree(tmp, ignore_errors=True)
    return _count_pairs(data)


def main() -> None:
    _ensure_path()
    parser = argparse.ArgumentParser()
    parser.add_argument("--data", type=Path, default=Path(__file__).parent / "data")
    parser.add_argument("--min", type=int, default=32)
    parser.add_argument("--n", type=int, default=64)
    args = parser.parse_args()
    args.data.mkdir(parents=True, exist_ok=True)
    if _count_pairs(args.data) >= args.min and (args.data / "READY").is_file():
        print(f"already ready: {_count_pairs(args.data)} pairs", flush=True)
        return
    err = None
    try:
        print(f"TFDS NYU → {fetch_tfds_nyu(args.data, max(args.n, args.min))} pairs", flush=True)
    except Exception as e:
        err = e
        print(f"TFDS failed: {e}", flush=True)
        try:
            print(f"Release sample → {fetch_release_zip(args.data)}", flush=True)
        except Exception as e2:
            err = e2
            print(f"Release sample failed: {e2}", flush=True)
    n = _count_pairs(args.data)
    if n < args.min:
        raise SystemExit(f"need ≥{args.min} pairs, found {n}. Last: {err}")
    (args.data / "READY").write_text("auto\n", encoding="utf-8")
    print(f"QUALITY data ready: {n} pairs", flush=True)


if __name__ == "__main__":
    main()
