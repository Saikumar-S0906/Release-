#!/usr/bin/env python3
"""M3 matting quality data — NO tensorflow_datasets.

Downloads Oxford-IIIT Pet images + trimap annotations directly from VGG.
"""

from __future__ import annotations

import argparse
import io
import shutil
import sys
import tarfile
import urllib.request
from pathlib import Path

import numpy as np

IMAGES_URL = "https://www.robots.ox.ac.uk/~vgg/data/pets/data/images.tar.gz"
ANNS_URL = "https://www.robots.ox.ac.uk/~vgg/data/pets/data/annotations.tar.gz"
SIZE = 256


def _ensure_path() -> None:
    here = Path(__file__).resolve().parent
    for p in (here, here.parent):
        if str(p) not in sys.path:
            sys.path.insert(0, str(p))


def _count_pairs(data: Path) -> int:
    from real_data import matte_pairs

    return len(matte_pairs(data))


def _download(url: str, dest: Path) -> None:
    print(f"downloading {url}", flush=True)

    def _progress(b, bs, t):
        if t and b % 40 == 0:
            print(f"  {min(100, int(100 * b * bs / t))}%", flush=True)

    urllib.request.urlretrieve(url, dest, reporthook=_progress)


def main() -> None:
    _ensure_path()
    try:
        from PIL import Image
    except ImportError:
        import subprocess

        subprocess.check_call([sys.executable, "-m", "pip", "install", "-q", "pillow"])
        from PIL import Image

    parser = argparse.ArgumentParser()
    parser.add_argument("--data", type=Path, default=Path(__file__).parent / "data")
    parser.add_argument("--min", type=int, default=32)
    parser.add_argument("--n", type=int, default=80)
    args = parser.parse_args()
    args.data.mkdir(parents=True, exist_ok=True)
    if _count_pairs(args.data) >= args.min and (args.data / "READY").is_file():
        print(f"already ready: {_count_pairs(args.data)} pairs", flush=True)
        return

    tmp = args.data / "_download"
    tmp.mkdir(parents=True, exist_ok=True)
    img_tar = tmp / "images.tar.gz"
    ann_tar = tmp / "annotations.tar.gz"
    try:
        _download(IMAGES_URL, img_tar)
        _download(ANNS_URL, ann_tar)
    except Exception as e:
        raise SystemExit(f"Oxford Pet download failed: {e}") from e

    img_dir = tmp / "images"
    trimap_dir = tmp / "trimaps"
    img_dir.mkdir(exist_ok=True)
    with tarfile.open(img_tar, "r:gz") as t:
        t.extractall(tmp)
    with tarfile.open(ann_tar, "r:gz") as t:
        t.extractall(tmp)
    # layout: tmp/images/*.jpg, tmp/annotations/trimaps/*.png
    images_root = tmp / "images"
    trimaps_root = tmp / "annotations" / "trimaps"
    if not trimaps_root.is_dir():
        trimaps_root = tmp / "trimaps"

    rgb_out, a_out = args.data / "rgb", args.data / "alpha"
    rgb_out.mkdir(parents=True, exist_ok=True)
    a_out.mkdir(parents=True, exist_ok=True)

    stems = sorted(
        p.stem
        for p in images_root.iterdir()
        if p.suffix.lower() in {".jpg", ".jpeg", ".png"} and not p.name.startswith(".")
    )
    count = 0
    for stem in stems:
        if count >= args.n:
            break
        # skip trimap helpers starting with .
        trip = None
        for cand in (trimaps_root / f"{stem}.png", trimaps_root / f"{stem}.jpg"):
            if cand.is_file() and not cand.name.startswith("."):
                trip = cand
                break
        if trip is None:
            continue
        # skip underscore preview trimaps
        if stem.startswith("._"):
            continue
        img_path = None
        for ext in (".jpg", ".jpeg", ".png"):
            p = images_root / f"{stem}{ext}"
            if p.is_file():
                img_path = p
                break
        if img_path is None:
            continue
        try:
            rgb = Image.open(img_path).convert("RGB").resize((SIZE, SIZE))
            tri = Image.open(trip).convert("L").resize((SIZE, SIZE), Image.NEAREST)
        except Exception:
            continue
        t = np.asarray(tri, dtype=np.float32)
        # Pet trimap: 1=fg, 2=bg, 3=border
        if t.max() > 1.5:
            alpha = ((t == 1).astype(np.float32) + 0.5 * (t == 3).astype(np.float32)).clip(0, 1)
        else:
            alpha = (t / 255.0).clip(0, 1)
        if float(alpha.mean()) < 0.02 or float(alpha.mean()) > 0.98:
            continue
        name = f"pet_{count:04d}"
        rgb.save(rgb_out / f"{name}.png")
        Image.fromarray((alpha * 255).astype(np.uint8), mode="L").save(a_out / f"{name}.png")
        count += 1
        if count % 20 == 0:
            print(f"  saved {count}", flush=True)

    shutil.rmtree(tmp, ignore_errors=True)
    n = _count_pairs(args.data)
    if n < args.min:
        raise SystemExit(f"need ≥{args.min} pairs, found {n}")
    (args.data / "READY").write_text("auto\n", encoding="utf-8")
    print(f"QUALITY data ready: {n} pairs (Oxford-IIIT Pet)", flush=True)


if __name__ == "__main__":
    main()
