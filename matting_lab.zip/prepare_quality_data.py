#!/usr/bin/env python3
"""Fetch public RGB+alpha pairs for M3 matting (auto — no upload).

Primary: TFDS Oxford-IIIT Pet segmentation (real photos + subject masks).
Writes data/rgb + data/alpha + READY.
"""

from __future__ import annotations

import argparse
import subprocess
import sys
from pathlib import Path

import numpy as np

SIZE = 256


def _ensure_path() -> None:
    here = Path(__file__).resolve().parent
    for p in (here, here.parent):
        if str(p) not in sys.path:
            sys.path.insert(0, str(p))


def _count_pairs(data: Path) -> int:
    from real_data import matte_pairs

    return len(matte_pairs(data))


def _save_pair(rgb_dir: Path, a_dir: Path, stem: str, rgb: np.ndarray, alpha: np.ndarray) -> None:
    from PIL import Image

    rgb_dir.mkdir(parents=True, exist_ok=True)
    a_dir.mkdir(parents=True, exist_ok=True)
    if rgb.dtype != np.uint8:
        rgb_u8 = (np.clip(rgb, 0, 1) * 255).astype(np.uint8) if float(np.max(rgb)) <= 1.5 else rgb.astype(np.uint8)
    else:
        rgb_u8 = rgb
    Image.fromarray(rgb_u8).resize((SIZE, SIZE)).save(rgb_dir / f"{stem}.png")
    a = alpha.astype(np.float32)
    if a.ndim == 3:
        a = a[..., 0]
    # Pet seg: 1=foreground, 2=background, 3=border — map to alpha
    if a.max() > 1.5:
        fg = (a == 1).astype(np.float32)
        border = (a == 3).astype(np.float32) * 0.5
        a01 = np.clip(fg + border, 0, 1)
    else:
        a01 = np.clip(a, 0, 1)
    Image.fromarray((a01 * 255).astype(np.uint8), mode="L").resize((SIZE, SIZE)).save(
        a_dir / f"{stem}.png"
    )


def fetch_tfds_pets(data: Path, n: int) -> int:
    subprocess.check_call([sys.executable, "-m", "pip", "install", "-q", "tensorflow-datasets", "pillow"])
    import tensorflow_datasets as tfds

    ds = tfds.load("oxford_iiit_pet", split=f"train[:{n}]", shuffle_files=False)
    rgb_dir, a_dir = data / "rgb", data / "alpha"
    count = 0
    for i, ex in enumerate(tfds.as_numpy(ds)):
        _save_pair(rgb_dir, a_dir, f"pet_{i:04d}", ex["image"], ex["segmentation_mask"])
        count += 1
        if count % 20 == 0:
            print(f"  saved {count}", flush=True)
    return count


def main() -> None:
    _ensure_path()
    parser = argparse.ArgumentParser()
    parser.add_argument("--data", type=Path, default=Path(__file__).parent / "data")
    parser.add_argument("--min", type=int, default=32)
    parser.add_argument("--n", type=int, default=80)
    args = parser.parse_args()
    args.data.mkdir(parents=True, exist_ok=True)
    if _count_pairs(args.data) >= args.min and (args.data / "READY").is_file():
        print(f"already ready: {_count_pairs(args.data)} pairs", flush=True)
        return
    try:
        got = fetch_tfds_pets(args.data, max(args.n, args.min))
        print(f"TFDS Oxford-IIIT Pet → {got} pairs", flush=True)
    except Exception as e:
        raise SystemExit(f"auto matte data failed: {e}") from e
    n = _count_pairs(args.data)
    if n < args.min:
        raise SystemExit(f"need ≥{args.min} pairs, found {n}")
    (args.data / "READY").write_text("auto\n", encoding="utf-8")
    print(f"QUALITY data ready: {n} pairs", flush=True)


if __name__ == "__main__":
    main()
