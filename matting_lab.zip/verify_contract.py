#!/usr/bin/env python3
"""Verify matting.tflite: 1x256x256x3 → 1x256x256x1 FLOAT32 alpha."""

from __future__ import annotations

import argparse
import hashlib
from pathlib import Path

import numpy as np
import tensorflow as tf

from config import ARTIFACT, MAX_APK_BUNDLE_BYTES, MAX_SMOKE_MAE, SIZE
from dataset import make_sample


def main() -> None:
    parser = argparse.ArgumentParser()
    parser.add_argument("--model", type=Path, default=Path(__file__).parent / "dist" / ARTIFACT)
    parser.add_argument("--max-mae", type=float, default=MAX_SMOKE_MAE)
    args = parser.parse_args()
    if not args.model.is_file():
        raise SystemExit(f"missing model: {args.model}")

    data = args.model.read_bytes()
    sha = hashlib.sha256(data).hexdigest()
    interpreter = tf.lite.Interpreter(model_content=data)
    interpreter.allocate_tensors()
    inputs = interpreter.get_input_details()
    outputs = interpreter.get_output_details()
    if len(inputs) != 1 or len(outputs) < 1:
        raise SystemExit(f"expected 1 in / 1 out, got {len(inputs)}/{len(outputs)}")

    in_shape = [int(x) for x in inputs[0]["shape"]]
    out_shape = [int(x) for x in outputs[0]["shape"]]
    print(f"in={in_shape} {inputs[0]['dtype']}")
    print(f"out={out_shape} {outputs[0]['dtype']}")
    print(f"sha256={sha}")
    print(f"bytes={len(data)}")
    print(
        "placement=github_release"
        if len(data) > MAX_APK_BUNDLE_BYTES
        else "placement=apk_assets"
    )

    if inputs[0]["dtype"] != np.float32 or outputs[0]["dtype"] != np.float32:
        raise SystemExit("dtype must be float32")
    if in_shape != [1, SIZE, SIZE, 3] or out_shape not in ([1, SIZE, SIZE, 1], [1, SIZE, SIZE]):
        raise SystemExit(f"shape contract failed: {in_shape} -> {out_shape}")

    rng = np.random.default_rng(0)
    errs = []
    for _ in range(80):
        img, alpha = make_sample(rng)
        interpreter.set_tensor(inputs[0]["index"], img[None, ...])
        interpreter.invoke()
        pred = interpreter.get_tensor(outputs[0]["index"])[0]
        if pred.ndim == 2:
            pred = pred[..., None]
        errs.append(float(np.abs(pred - alpha).mean()))
    mae = float(np.mean(errs))
    print(f"alpha_mae={mae:.4f}")
    if mae > args.max_mae:
        raise SystemExit(f"alpha MAE {mae:.4f} exceeds {args.max_mae}")
    print("OK")


if __name__ == "__main__":
    main()
