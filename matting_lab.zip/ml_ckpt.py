"""Shared checkpoint load helpers for Wave M labs (Colab / Keras 3 safe)."""

from __future__ import annotations

from pathlib import Path
from typing import Callable

import tensorflow as tf


def load_keras_or_weights(
    path: Path,
    build_fn: Callable[[], tf.keras.Model],
    *,
    compile_fn: Callable[[tf.keras.Model], None] | None = None,
) -> tf.keras.Model:
    """Load full .keras model, or rebuild + load_weights (with by_name fallback)."""
    try:
        return tf.keras.models.load_model(path, safe_mode=False)
    except Exception as e:
        print(f"load_model {path.name} failed: {e}", flush=True)
        model = build_fn()
        if compile_fn is not None:
            compile_fn(model)
        try:
            model.load_weights(path)
            print(f"loaded weights from {path}", flush=True)
            return model
        except Exception as e2:
            print(f"load_weights strict failed ({e2}); by_name skip_mismatch", flush=True)
            model.load_weights(path, skip_mismatch=True, by_name=True)
            return model


def resume_into(
    model: tf.keras.Model,
    ckpt_path: Path,
) -> bool:
    """Load checkpoint weights into an already-built model. Returns True if loaded."""
    if not ckpt_path.is_file():
        print(f"resume skipped — no file {ckpt_path}", flush=True)
        return False
    try:
        model.load_weights(ckpt_path)
        print(f"resumed weights from {ckpt_path}", flush=True)
        return True
    except Exception as e:
        print(f"resume load_weights failed ({e}); by_name skip_mismatch", flush=True)
        try:
            model.load_weights(ckpt_path, skip_mismatch=True, by_name=True)
            print(f"resumed (partial) from {ckpt_path}", flush=True)
            return True
        except Exception as e2:
            print(f"resume failed: {e2}", flush=True)
            return False


def load_for_export(
    keras_path: Path,
    build_fn: Callable[[], tf.keras.Model],
    *,
    allow_untrained: bool,
) -> tf.keras.Model:
    candidates = [keras_path, keras_path.with_suffix(".ckpt.keras")]
    seen: set[Path] = set()
    for path in candidates:
        if path in seen:
            continue
        seen.add(path)
        if not (path.is_file() or path.is_dir()):
            continue
        return load_keras_or_weights(path, build_fn)
    if allow_untrained:
        print("no keras checkpoint; exporting untrained graph")
        return build_fn()
    raise SystemExit(
        "FATAL: no loadable trained checkpoint — refusing untrained export. "
        "Re-run train.py, then export (do not pin random weights)."
    )
