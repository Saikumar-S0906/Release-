# Quality data layout (M3 Matting)

**Do not pin Release- weights trained only on synthetic smoke.**

1. Stage pairs:
   - `rgb/` — frames
   - `alpha/` — same stem, soft alpha (hair edges matter)
2. Touch empty file `READY`
3. Train: `python train.py --quality --data ./data`

Sources: VideoMatte240K / MODNet-style / AIM. See `tools/ML_QUALITY_BAR.md`.
