# PixiJoy matting lab (M3 / H6)

Subject alpha matte → `matting.tflite`.

**Ship rule:** only `--quality` + `data/READY`. Smoke ≠ Release-.  
Law: [`../ML_QUALITY_BAR.md`](../ML_QUALITY_BAR.md)

## Contract

| | Shape | Dtype |
|---|-------|-------|
| In0 image | `1×256×256×3` | FLOAT32 |
| Out0 alpha | `1×256×256×1` | FLOAT32 (1 = foreground) |

## Quality

Stage VideoMatte/AIM-style `data/rgb` + `data/alpha` → `READY` → `python train.py --quality`

## Smoke

```bash
python train.py
python export_tflite.py
python verify_contract.py
```
