#!/usr/bin/env python3
"""Fetch public real photos for M1 quality inpaint (no manual upload required).

Default source: DIV2K validation HR (~100 images) — open research set.
Writes data/rgb/*.png and data/READY.

  python prepare_quality_data.py
  python prepare_quality_data.py --data ./data --min 32
"""

from __future__ import annotations

import argparse
import io
import shutil
import urllib.request
import zipfile
from pathlib import Path

# DIV2K valid HR — ~445 MB, ~100 high-res photos (CC BY-NC? check ETH — research use).
# License: DIV2K is provided by ETH Zurich for academic research; PixiJoy on-device
# distill of a student UNet trained on these stills is the intended Wave M path.
DIV2K_VALID_HR = "http://data.vision.ee.ethz.ch/cvl/DIV2K/DIV2K_valid_HR.zip"

# Smaller fallback (~ few dozen) if DIV2K is blocked — Wikimedia Commons sample pack
# hosted on Release- when present.
RELEASE_SAMPLE = (
    "https://raw.githubusercontent.com/Saikumar-S0906/Release-/main/inpaint_rgb_sample.zip"
)


def _count_rgb(rgb: Path) -> int:
    exts = {".png", ".jpg", ".jpeg", ".webp", ".bmp"}
    if not rgb.is_dir():
        return 0
    return sum(1 for p in rgb.iterdir() if p.suffix.lower() in exts)


def _extract_images_from_zip(zpath: Path, rgb: Path) -> int:
    rgb.mkdir(parents=True, exist_ok=True)
    n = 0
    with zipfile.ZipFile(zpath) as z:
        for info in z.infolist():
            if info.is_dir():
                continue
            name = Path(info.filename).name
            if Path(name).suffix.lower() not in {".png", ".jpg", ".jpeg", ".webp", ".bmp"}:
                continue
            if name.startswith("."):
                continue
            dest = rgb / name
            with z.open(info) as src, open(dest, "wb") as dst:
                shutil.copyfileobj(src, dst)
            n += 1
    return n


def download(url: str, dest: Path) -> None:
    print(f"downloading {url}", flush=True)
    dest.parent.mkdir(parents=True, exist_ok=True)

    def _progress(block: int, block_size: int, total: int) -> None:
        if total <= 0:
            return
        done = block * block_size
        pct = min(100, int(100 * done / total))
        if block % 50 == 0 or done >= total:
            print(f"  {pct}% ({done // (1024 * 1024)} MB)", flush=True)

    urllib.request.urlretrieve(url, dest, reporthook=_progress)


def main() -> None:
    parser = argparse.ArgumentParser()
    parser.add_argument("--data", type=Path, default=Path(__file__).parent / "data")
    parser.add_argument("--min", type=int, default=32)
    parser.add_argument(
        "--source",
        choices=("auto", "div2k", "release", "skip"),
        default="auto",
        help="auto tries DIV2K then Release- sample",
    )
    args = parser.parse_args()
    rgb = args.data / "rgb"
    rgb.mkdir(parents=True, exist_ok=True)
    n = _count_rgb(rgb)
    if n >= args.min and (args.data / "READY").is_file():
        print(f"already ready: {n} images in {rgb}", flush=True)
        return

    if args.source == "skip":
        raise SystemExit("skip requested but data incomplete")

    tmp = args.data / "_download"
    tmp.mkdir(parents=True, exist_ok=True)
    fetched = 0
    sources: list[tuple[str, str]] = []
    if args.source in ("auto", "div2k"):
        sources.append(("div2k", DIV2K_VALID_HR))
    if args.source in ("auto", "release"):
        sources.append(("release", RELEASE_SAMPLE))

    last_err: Exception | None = None
    for label, url in sources:
        zpath = tmp / f"{label}.zip"
        try:
            download(url, zpath)
            fetched = _extract_images_from_zip(zpath, rgb)
            print(f"extracted {fetched} images from {label}", flush=True)
            if _count_rgb(rgb) >= args.min:
                break
        except Exception as e:
            last_err = e
            print(f"{label} failed: {e}", flush=True)

    n = _count_rgb(rgb)
    if n < args.min:
        raise SystemExit(
            f"need ≥{args.min} photos in {rgb}, found {n}. "
            f"Last error: {last_err}. Upload manually or fix network."
        )

    (args.data / "READY").write_text("auto\n", encoding="utf-8")
    print(f"QUALITY data ready: {n} photos → {rgb} + READY", flush=True)
    # cleanup zip to save disk
    shutil.rmtree(tmp, ignore_errors=True)


if __name__ == "__main__":
    main()
