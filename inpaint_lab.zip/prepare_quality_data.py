#!/usr/bin/env python3
"""M1 quality data — DIV2K only (no TFDS / no Drive required)."""

from __future__ import annotations

import argparse
import shutil
import urllib.request
import zipfile
from pathlib import Path

DIV2K_VALID_HR = "http://data.vision.ee.ethz.ch/cvl/DIV2K/DIV2K_valid_HR.zip"
# Mirror (GitHub raw often works when ETH is slow)
DIV2K_MIRROR = "https://huggingface.co/datasets/eugenesiow/div2k/resolve/main/DIV2K_valid_HR.zip"


def _count_rgb(rgb: Path) -> int:
    exts = {".png", ".jpg", ".jpeg", ".webp", ".bmp"}
    if not rgb.is_dir():
        return 0
    return sum(1 for p in rgb.iterdir() if p.suffix.lower() in exts)


def _download(url: str, dest: Path) -> None:
    print(f"downloading {url}", flush=True)

    def _progress(b, bs, t):
        if t and b % 30 == 0:
            print(f"  {min(100, int(100 * b * bs / t))}%", flush=True)

    urllib.request.urlretrieve(url, dest, reporthook=_progress)


def _extract_images(zpath: Path, rgb: Path) -> int:
    rgb.mkdir(parents=True, exist_ok=True)
    n = 0
    with zipfile.ZipFile(zpath) as z:
        for info in z.infolist():
            if info.is_dir():
                continue
            name = Path(info.filename).name
            if Path(name).suffix.lower() not in {".png", ".jpg", ".jpeg", ".webp", ".bmp"}:
                continue
            dest = rgb / name
            with z.open(info) as src, open(dest, "wb") as dst:
                shutil.copyfileobj(src, dst)
            n += 1
    return n


def main() -> None:
    parser = argparse.ArgumentParser()
    parser.add_argument("--data", type=Path, default=Path(__file__).parent / "data")
    parser.add_argument("--min", type=int, default=32)
    args = parser.parse_args()
    rgb = args.data / "rgb"
    rgb.mkdir(parents=True, exist_ok=True)
    if _count_rgb(rgb) >= args.min and (args.data / "READY").is_file():
        print(f"already ready: {_count_rgb(rgb)} images", flush=True)
        return

    tmp = args.data / "_download"
    tmp.mkdir(parents=True, exist_ok=True)
    zpath = tmp / "div2k.zip"
    err = None
    for url in (DIV2K_VALID_HR, DIV2K_MIRROR):
        try:
            _download(url, zpath)
            n = _extract_images(zpath, rgb)
            print(f"extracted {n} from {url}", flush=True)
            if _count_rgb(rgb) >= args.min:
                break
        except Exception as e:
            err = e
            print(f"failed {url}: {e}", flush=True)

    shutil.rmtree(tmp, ignore_errors=True)
    n = _count_rgb(rgb)
    if n < args.min:
        raise SystemExit(f"need ≥{args.min} photos in {rgb}, found {n}. Last: {err}")
    (args.data / "READY").write_text("auto\n", encoding="utf-8")
    print(f"QUALITY data ready: {n} photos (DIV2K)", flush=True)


if __name__ == "__main__":
    main()
