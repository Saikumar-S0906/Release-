# PixiJoy neural inpaint lab (M1 / E1)

Full UNet → `inpaint.tflite`. Hardened: no Lambda, safe ckpt load, refuses untrained export.

**Ship rule:** only `python train.py --quality` after `data/READY` + ≥32 real photos. Smoke ≠ Release-.  
Law: [`../ML_QUALITY_BAR.md`](../ML_QUALITY_BAR.md)

## Contract

| | Shape | Dtype |
|---|-------|-------|
| In0 image | `1×256×256×3` | FLOAT32 |
| In1 mask | `1×256×256×1` | FLOAT32 (1 = hole) |
| Out0 RGB | `1×256×256×3` | FLOAT32 |

## Colab GPU (quality — product)

1. Open: https://colab.research.google.com/github/Saikumar-S0906/Release-/blob/main/train_colab.ipynb
2. Runtime → **GPU**
3. Stage `data/rgb` (≥32 photos) + touch `data/READY` (upload zip or Drive) — see `data/README.md`
4. Notebook `TRAIN_MODE = "quality"` → **Run all**
5. Pin `inpaint.tflite` to [ml-packs-v1](https://github.com/Saikumar-S0906/Release-/releases/tag/ml-packs-v1) **only if** `verify_contract.py --quality` passes (masked MAE ≤ 0.08)

**Fresh Run all = from scratch.** Resume: copy `dist/*.ckpt.keras` to Drive, restore, `python train.py --quality --resume`.

## Smoke (contract only — never pin)

```bash
python train.py --smoke
python export_tflite.py
python verify_contract.py
```
