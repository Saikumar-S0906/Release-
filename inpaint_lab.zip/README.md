# Quality data layout (M1 Inpaint)

**Do not pin Release- weights trained only on synthetic smoke.**

1. Stage real photos:
   - `rgb/` — ≥32 photos (png/jpg/webp). Places2 / DIV2K / COCO stills / phone photos.
   - `masks/` — **optional** paired hole masks (same stem, 1=hole). If missing, irregular free-form masks are applied on the real photo (Places2-style self-supervised).
2. Touch empty file `READY`
3. Train: `python train.py --quality --data ./data`
4. Export + verify: `python export_tflite.py && python verify_contract.py --quality`

**Quality gate:** masked MAE ≤ **0.08** on held-out real holes (`tools/ML_QUALITY_BAR.md`).

Cheap = synthetic-only train labeled as product. Not allowed.
