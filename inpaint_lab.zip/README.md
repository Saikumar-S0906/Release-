# PixiJoy neural inpaint lab

Full UNet train/export/verify for `inpaint.tflite`.

## Colab GPU (recommended)

1. Open: https://colab.research.google.com/github/Saikumar-S0906/Release-/blob/main/train_colab.ipynb
2. Runtime → Change runtime type → **GPU**
3. Runtime → **Run all**
4. Download `inpaint.tflite` when the last cell finishes
5. Attach it to https://github.com/Saikumar-S0906/Release-/releases/tag/ml-packs-v1 **only if verify passes**

**Fresh Run all = train from scratch** (Colab `/content` is wiped). Resume only if you copied `dist/*.ckpt.keras` to Drive and run `python train.py --resume` after restoring it.

**Do not pin** a run that printed `exporting untrained graph` or failed verify.

## Local

```bash
cd tools/inpaint
python train.py
python export_tflite.py
python verify_contract.py
```

Contract (FLOAT32): image `1×256×256×3` + mask `1×256×256×1` → RGB `1×256×256×3`.
Quality is not compromised for APK size — large exports go to Release-.
