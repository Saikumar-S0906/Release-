# PixiJoy reusable components
AIActionCard
PrimaryButton / SecondaryButton / IconButton
PromptBar / SuggestionChip
MediaCard / TemplateCard / ResultCard
BeforeAfterSlider
GenerationProgress
BottomSheet
PermissionCard
ErrorState / EmptyState
ShareDestinationCard
CreditBalanceCard / SubscriptionCard
NotificationRow / PrivacyRow / AccountRow
FilterChip / SegmentedControl
MediaGrid / Timeline / LayerRow / StickerTile
