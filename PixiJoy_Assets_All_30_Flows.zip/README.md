# PixiJoy — Assets for All 30 UX Flows

This is a development starter pack for the complete 30-flow PixiJoy product.

Included:
- Brand SVG masters
- Design tokens
- Reusable UI icons
- AI/system/privacy/account illustrations
- 30 flow-specific asset manifests
- Master flow registry
- Motion rules
- Template/sticker/sample placeholders via manifest structure
- AI-agent asset rules
- Licensing checklist
- Play Store asset checklist

Important:
The included creative/template/illustration files are development placeholders.
Production content must be created, licensed, or otherwise cleared for use.
Large creative libraries should be delivered through a CDN/content-management system
rather than bundled into the base APK.

Product rule:
Adult-quality design. Child-level simplicity.
One Photo. Endless Possibilities.
