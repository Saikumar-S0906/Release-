# Production Content Licensing Checklist
Before release, clear rights for:
- fonts
- stock photos/video
- meme templates
- GIF/reaction media
- sticker/illustration packs
- music/audio
- platform logos
- AI model/provider usage terms
- community/creator content

Keep a source/license record: asset_id, source, creator, license, attribution, expiry/review date.
